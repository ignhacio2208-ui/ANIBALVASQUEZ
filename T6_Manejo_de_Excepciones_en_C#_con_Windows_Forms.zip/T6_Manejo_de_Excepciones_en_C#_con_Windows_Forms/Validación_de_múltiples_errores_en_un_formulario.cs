﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace T6_Manejo_de_Excepciones_en_C__con_Windows_Forms
{
    public partial class Validación_de_múltiples_errores_en_un_formulario : Form
    {
        public Validación_de_múltiples_errores_en_un_formulario()
        {
            InitializeComponent();
        }

        private void Validación_de_múltiples_errores_en_un_formulario_Load(object sender, EventArgs e)
        {

        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            try
            {
                string nombre = txtNombre.Text.Trim();

                // Validar que el nombre no esté vacío
                if (string.IsNullOrEmpty(nombre))
                {
                    throw new Exception("El nombre no puede estar vacío.");
                }

                // Validar que el nombre contenga solo letras (opcionalmente con espacios)
                if (!Regex.IsMatch(nombre, @"^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$"))
                {
                    throw new Exception("El nombre solo debe contener letras y espacios.");
                }

                int edad = int.Parse(txtEdad.Text);
                decimal salario = decimal.Parse(txtSalario.Text);

                // Formatear salario en dólares (USD)
                string salarioFormateado = salario.ToString("C", CultureInfo.GetCultureInfo("en-US"));

                lblResultado.Text = $"Nombre: {nombre} | Edad: {edad} | Salario: {salarioFormateado}";
            }
            catch (FormatException)
            {
                lblResultado.Text = "";
                MessageBox.Show("Por favor verifica que la edad sea un número entero y el salario un número decimal válido.", "Error de formato", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                lblResultado.Text = "";
                MessageBox.Show($"Error: {ex.Message}", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
