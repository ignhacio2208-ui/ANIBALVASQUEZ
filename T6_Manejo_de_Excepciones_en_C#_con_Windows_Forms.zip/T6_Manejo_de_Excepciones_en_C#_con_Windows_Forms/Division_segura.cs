﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace T6_Manejo_de_Excepciones_en_C__con_Windows_Forms
{
    public partial class División_segura : Form
    {
        public División_segura()
        {
            InitializeComponent();
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            try
            {
                // Intentar convertir las entradas a enteros
                int numerador = int.Parse(txtNumerador.Text);
                int denominador = int.Parse(txtDenominador.Text);

                // Verificar división por cero
                int resultado = numerador / denominador;
                lblResultado.Text = $"Resultado: {resultado}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor ingrese números válidos.", "Error de formato", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (DivideByZeroException)
            {
                MessageBox.Show("No se puede dividir entre cero.", "Error de división", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                MessageBox.Show("Proceso finalizado", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void División_segura_Load(object sender, EventArgs e)
        {

        }
    }
}
