﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace T6_Manejo_de_Excepciones_en_C__con_Windows_Forms
{
    public partial class Conversión_edad : Form
    {
        public Conversión_edad()
        {
            InitializeComponent();
        }

        private void btnConvertir_Click(object sender, EventArgs e)
        {
            try
            {
                int edad = int.Parse(txtEdad.Text);
                MessageBox.Show($"Tienes {edad} años", "Edad", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor ingresa una edad válida en números.", "Error de formato", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
