﻿namespace T6_Manejo_de_Excepciones_en_C__con_Windows_Forms
{
    partial class Acceso_a_índice_en_arreglo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtIndice = new System.Windows.Forms.TextBox();
            this.btnMostrarNombre = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtIndice
            // 
            this.txtIndice.Location = new System.Drawing.Point(29, 61);
            this.txtIndice.Name = "txtIndice";
            this.txtIndice.Size = new System.Drawing.Size(100, 20);
            this.txtIndice.TabIndex = 0;
            // 
            // btnMostrarNombre
            // 
            this.btnMostrarNombre.Location = new System.Drawing.Point(29, 102);
            this.btnMostrarNombre.Name = "btnMostrarNombre";
            this.btnMostrarNombre.Size = new System.Drawing.Size(100, 36);
            this.btnMostrarNombre.TabIndex = 1;
            this.btnMostrarNombre.Text = "Mostrar ";
            this.btnMostrarNombre.UseVisualStyleBackColor = true;
            this.btnMostrarNombre.Click += new System.EventHandler(this.btnMostrarNombre_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(26, 156);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(115, 13);
            this.lblResultado.TabIndex = 2;
            this.lblResultado.Text = "__________________";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Indice:";
            // 
            // Acceso_a_índice_en_arreglo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(273, 232);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.btnMostrarNombre);
            this.Controls.Add(this.txtIndice);
            this.Name = "Acceso_a_índice_en_arreglo";
            this.Text = "Acceso_a_índice_en_arreglo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtIndice;
        private System.Windows.Forms.Button btnMostrarNombre;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Label label1;
    }
}