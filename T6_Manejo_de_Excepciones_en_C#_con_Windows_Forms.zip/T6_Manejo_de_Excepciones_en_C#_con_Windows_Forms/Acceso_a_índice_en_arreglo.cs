﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace T6_Manejo_de_Excepciones_en_C__con_Windows_Forms
{
    public partial class Acceso_a_índice_en_arreglo : Form
    {
        string[] nombres = { "Ana", "Luis", "Carlos", "María", "Jorge" };
        public Acceso_a_índice_en_arreglo()
        {
            InitializeComponent();
        }

        private void btnMostrarNombre_Click(object sender, EventArgs e)
        {
            try
            {
                int indice = int.Parse(txtIndice.Text);
                string nombre = nombres[indice];
                lblResultado.Text = $"Nombre: {nombre}";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor ingresa un número válido.", "Error de formato", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (IndexOutOfRangeException)
            {
                MessageBox.Show("El índice debe estar entre 0 y 4.", "Índice fuera de rango", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
