﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace T6_Manejo_de_Excepciones_en_C__con_Windows_Forms
{
    public partial class Carga_de_archivo_inexistente : Form
    {
        public Carga_de_archivo_inexistente()
        {
            InitializeComponent();
        }

        private void btnCargarArchivo_Click(object sender, EventArgs e)
        {
            string rutaArchivo = "C:\\archivox.txt";

            try
            {
                string contenido = File.ReadAllText(rutaArchivo);
                MessageBox.Show("Archivo leído exitosamente:\n\n" + contenido, "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("El archivo no existe en la ruta especificada:\n" + rutaArchivo, "Archivo no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
