﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace T6_Manejo_de_Excepciones_en_C__con_Windows_Forms
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new División_segura());
            Application.Run(new Conversión_edad());
            Application.Run(new Acceso_a_índice_en_arreglo());
            Application.Run(new Carga_de_archivo_inexistente());
            Application.Run(new Validación_de_múltiples_errores_en_un_formulario());
        }
    }
}
